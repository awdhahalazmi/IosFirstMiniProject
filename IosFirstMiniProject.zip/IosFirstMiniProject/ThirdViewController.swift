//
//  ThirdViewController.swift
//  IosFirstMiniProject
//
//  Created by Awdhah Alazemi on 29/02/2024.
//

import UIKit

class ThirdViewController: UIViewController {
    let hrLabel = UILabel()
    let infoLabel = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(hrLabel)
        view.addSubview(infoLabel)
        
        layoutInfo( )
        SetUpUI( )

    }
    
    func SetUpUI( ){
        
        
        
        hrLabel.text = "Hr Information ℹ️".localized()
        hrLabel.textColor = .black
        hrLabel.font = UIFont.boldSystemFont(ofSize: 20.0)
        
        infoLabel.text = "bio"
       infoLabel.textColor = .black
        infoLabel.text = "⚖️ Equal Employment Opportunity (EEO) Policy: Ensures fair treatment of all employees and applicants, prohibiting discrimination based on protected characteristics.\n \n 📃 Code of Conduct Policy: Establishes expectations for ethical behavior, professionalism, and respect in the workplace, outlining consequences for violations .\n \n 🕓 Leave and Time Off Policy: Defines types of leave available to employees, eligibility criteria, and procedures for requesting and managing absences.".localized()
       infoLabel.font = UIFont.boldSystemFont(ofSize: 13.0)
       infoLabel.numberOfLines = 20
        
        
        
    }
    func layoutInfo( ){
        
        
        hrLabel.snp.makeConstraints { make in
                
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(20)
            make.centerX.equalToSuperview()
                
            }
        
        infoLabel.snp.makeConstraints { make in
            make.bottom.equalTo(hrLabel.snp.bottom).offset(250)
            make.centerX.equalToSuperview( )
            make.width.equalTo(300)        }
        
    }
    
    

   

}

