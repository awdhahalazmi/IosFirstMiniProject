//
//  ViewController.swift
//  IosFirstMiniProject
//
//  Created by Awdhah Alazemi on 29/02/2024.
//

import UIKit
import SnapKit

class ViewController: UIViewController , UITextFieldDelegate{
    let nameTextField = UITextField()
    let imageTextField = UITextField()
    let emailTextField = UITextField()
    let phoneTextField = UITextField()
    let ibanTextField = UITextField()
    let salaryTextField = UITextField()
    let saveButton = UIButton( )
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(saveButton)
        view.addSubview(nameTextField)
        view.addSubview(imageTextField)
        view.addSubview(emailTextField)
        view.addSubview(phoneTextField)
        view.addSubview(ibanTextField)
        view.addSubview(salaryTextField)
        phoneTextField.delegate = self

              
        
    
        
        
        view.backgroundColor = .white
        title = "Write Employee Info".localized()
        
        setUpUI()
        layoutSetUp()
        setUPnavBar( )
        setupNavigationBar( )
        
        saveButton.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        
        
        
    }
    
    
    func setUpUI( ){
        
        saveButton.setTitle("Save".localized(), for: .normal)
        saveButton.backgroundColor = .systemCyan
        saveButton.tintColor = .white
        saveButton.layer.cornerRadius = 10
        
        let symbolConfig = UIImage.SymbolConfiguration(pointSize: 16, weight: .medium, scale: .medium)
        
        let symbolImage = UIImage(systemName: "person.text.rectangle.fill",withConfiguration: symbolConfig)
        
        saveButton.setImage(symbolImage, for: .normal)
        
        
        
        nameTextField.attributedPlaceholder = NSAttributedString(
            string: "type the name".localized(),
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        nameTextField.font = UIFont.systemFont(ofSize: 13)
        nameTextField.textAlignment = .center
        nameTextField.layer.borderColor = UIColor.gray.cgColor
        nameTextField.tintColor = .darkGray
        nameTextField.keyboardType = .phonePad
        nameTextField.layer.borderColor = UIColor.black.cgColor
        nameTextField.layer.borderWidth = 1
        nameTextField.layer.cornerRadius = 5
      
        
        
        imageTextField.attributedPlaceholder = NSAttributedString(
            string: "type galaxy or Info or greenCard".localized(),
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        imageTextField.font = UIFont.systemFont(ofSize: 13)
        imageTextField.textAlignment = .center
        imageTextField.layer.borderColor = UIColor.gray.cgColor
        imageTextField.tintColor = .darkGray
        imageTextField.keyboardType = .phonePad
        imageTextField.layer.borderColor = UIColor.black.cgColor
       imageTextField.layer.borderWidth = 1
       imageTextField.layer.cornerRadius = 5
        
        phoneTextField.attributedPlaceholder = NSAttributedString(
            string: "type the phone number".localized(),
                attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
            phoneTextField.font = UIFont.systemFont(ofSize: 13)
            phoneTextField.textAlignment = .center
            phoneTextField.layer.borderColor = UIColor.gray.cgColor
            phoneTextField.tintColor = .darkGray
            phoneTextField.keyboardType = .phonePad
            phoneTextField.layer.borderColor = UIColor.black.cgColor
            phoneTextField.layer.borderWidth = 1
            phoneTextField.layer.cornerRadius = 5
        
        
        ibanTextField.attributedPlaceholder = NSAttributedString(
            string: "type the IBAN ".localized(),
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        ibanTextField.font = UIFont.systemFont(ofSize: 13)
        ibanTextField.textAlignment = .center
        ibanTextField.layer.borderColor = UIColor.gray.cgColor
        ibanTextField.tintColor = .darkGray
        ibanTextField.keyboardType = .phonePad
        ibanTextField.layer.borderColor = UIColor.black.cgColor
      ibanTextField.layer.borderWidth = 1
      ibanTextField.layer.cornerRadius = 5
        
        
        salaryTextField.attributedPlaceholder = NSAttributedString(
            string: "type the salary".localized(),
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        salaryTextField.font = UIFont.systemFont(ofSize: 13)
        salaryTextField.textAlignment = .center
        salaryTextField.layer.borderColor = UIColor.gray.cgColor
        salaryTextField.tintColor = .darkGray
        salaryTextField.keyboardType = .phonePad
        salaryTextField.layer.borderColor = UIColor.black.cgColor
        salaryTextField.layer.borderWidth = 1
        salaryTextField.layer.cornerRadius = 5
        
        emailTextField.attributedPlaceholder = NSAttributedString(
            string: "type the email".localized(),
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        emailTextField.font = UIFont.systemFont(ofSize: 13)
        emailTextField.textAlignment = .center
        emailTextField.layer.borderColor = UIColor.gray.cgColor
        emailTextField.tintColor = .darkGray
        emailTextField.keyboardType = .phonePad
        emailTextField.layer.borderColor = UIColor.black.cgColor
        emailTextField.layer.borderWidth = 1
        emailTextField.layer.cornerRadius = 5
        
    }

    func layoutSetUp() {
        let verticalSpacing: CGFloat = 45

        saveButton.snp.makeConstraints { make in

            make.top.equalTo(salaryTextField.snp.bottom).offset(verticalSpacing)
                   make.centerX.equalToSuperview()
                   make.width.equalTo(200)
                   make.height.equalTo(50)
               }
        
        nameTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().multipliedBy(0.4)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        imageTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(nameTextField.snp.bottom).offset(verticalSpacing)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        emailTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(imageTextField.snp.bottom).offset(verticalSpacing)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        phoneTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(emailTextField.snp.bottom).offset(verticalSpacing)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        ibanTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(phoneTextField.snp.bottom).offset(verticalSpacing)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        salaryTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalTo(ibanTextField.snp.bottom).offset(verticalSpacing)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
    }


    
    
    @objc func saveButtonTapped( ){
        //nav code
        let secondVC = SecondViewController( )
        
        secondVC.receviedName = nameTextField.text
        secondVC.receviedEmail = emailTextField.text
        secondVC.receviedImage = imageTextField.text
        secondVC.receviedPhone = phoneTextField.text
        secondVC.receviedIban = ibanTextField.text
        secondVC.receviedSalary = salaryTextField.text
        
        
        
        self.navigationController?.pushViewController(secondVC, animated: true)}
        
        
        //nav code
        
        func setUPnavBar( ){
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            navigationController?.navigationBar.scrollEdgeAppearance = appearance
            
        }
    
    

    
    
    func setupNavigationBar() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "info.circle.fill"),
            style: .plain,
            target: self,
            action: #selector(thePopOver)
        )
        navigationItem.leftBarButtonItem?.tintColor = UIColor.systemCyan
    }
    @objc func thePopOver( ){
        
        let thirdVC = ThirdViewController( )
        thirdVC.modalPresentationStyle = .popover
     self.present(thirdVC, animated: true )

    }
        
    func textField(_ phoneTextField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            
            let currentText = phoneTextField.text ?? ""
            let newText = (currentText as NSString).replacingCharacters(in: range, with: string)
            let maxLength = 8
            return newText.count <= maxLength
        }
        
    
    
}

extension String {
    func localized() -> String {
        NSLocalizedString(self, tableName: "Localizable", bundle: .main, value: self, comment: self)
    }
}
