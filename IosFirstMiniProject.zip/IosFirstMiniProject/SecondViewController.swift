//
//  SecondViewController.swift
//  IosFirstMiniProject
//
//  Created by Awdhah Alazemi on 29/02/2024.
//

import UIKit

class SecondViewController: UIViewController {
    var receviedName : String?
    let nameLabel = UILabel()
    
    var receviedImage : String?
    let imageView = UIImageView()
    
    var receviedEmail : String?
    let emailLabel = UILabel()
    
    var receviedPhone : String?
    let phoneLabel = UILabel()
    
    var receviedIban : String?
    let ibanLabel = UILabel()
    
    var receviedSalary : String?
    let salaryLabel = UILabel()
    
    let mycontainer = UIView()
    
    
    
    let nameText = UILabel()
    let emailText = UILabel()
    let phoneText = UILabel()
    let ibanText = UILabel()
    let salaryText = UILabel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(imageView)
        view.addSubview(mycontainer)
        mycontainer.addSubview(nameLabel)
        mycontainer.addSubview(emailLabel)
        mycontainer.addSubview(phoneLabel)
        mycontainer.addSubview(ibanLabel)
        mycontainer.addSubview(salaryLabel)
        view.addSubview(nameText)
        view.addSubview(emailText)
        view.addSubview(phoneText)
        view.addSubview(ibanText)
        view.addSubview(salaryText)
        title = "Employee Info ℹ️".localized()
        
        layoutSetUp()
        setUpUI()
        
        nameLabel.text = receviedName
        emailLabel.text = receviedEmail
        phoneLabel.text = receviedPhone
        ibanLabel.text = receviedIban
        salaryLabel.text = receviedSalary
        imageView.image = UIImage(named: receviedImage!)
        
        
        
    }
    
    
    
    func setUpUI( ){
        
        nameText.text = "Name: ".localized()
        nameText.font = .systemFont(ofSize: 13, weight: .bold)
        
        emailText.text = "Email: ".localized()
        emailText.font = .systemFont(ofSize: 13, weight: .bold)
        
        phoneText.text = "Phone: ".localized()
        phoneText.font = .systemFont(ofSize: 13, weight: .bold)
        
        ibanText.text = "IBAN: ".localized()
        ibanText.font = .systemFont(ofSize: 13, weight: .bold)
        
        salaryText.text = "Salary: ".localized()
        salaryText.font = .systemFont(ofSize: 13, weight: .bold)
        
        
        
        imageView.contentMode = .scaleToFill
        
        nameLabel.text = receviedName
        nameLabel.tintColor = .black
        nameLabel.font = UIFont.systemFont(ofSize: 13)
        nameLabel.textAlignment = .center
        
        
        
        
        
        
        emailLabel.text = receviedEmail
        emailLabel.tintColor = .black
        emailLabel.textAlignment = .center
        emailLabel.font = UIFont.systemFont(ofSize: 13)
        
        
        
        phoneLabel.text = receviedPhone
        phoneLabel.tintColor = .black
        phoneLabel.textAlignment = .center
        phoneLabel.font = UIFont.systemFont(ofSize: 13)
        
        
        
        ibanLabel.text = receviedIban
        ibanLabel.tintColor = .black
        ibanLabel.textAlignment = .center
        ibanLabel.font = UIFont.systemFont(ofSize: 13)
        
        
        
        
        salaryLabel.text = receviedSalary
        salaryLabel.tintColor = .black
        salaryLabel.textAlignment = .center
        salaryLabel.font = UIFont.systemFont(ofSize: 13)
        
        
        
    }
    
    func layoutSetUp() {
        
        // Constraints for imageView
        imageView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.height.width.equalTo(320)
        }
        
        // Constraints for mycontainer
        mycontainer.snp.makeConstraints { make in
            make.top.equalTo(imageView.snp.bottom)
            make.leading.trailing.equalToSuperview()
        }
        
        // Constraints for nameLabel
        nameLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(20) // Adjust the offset as needed
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        // Constraints for emailLabel
        emailLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(nameLabel.snp.bottom).offset(10) // Adjust the offset as needed
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        phoneLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(emailLabel.snp.bottom).offset(10) // Adjust the offset as needed
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        ibanLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(phoneLabel.snp.bottom).offset(10)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        
        salaryLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(ibanLabel.snp.bottom).offset(10)
            make.height.equalTo(40)
            make.width.equalTo(200)
        }
        nameText.snp.makeConstraints { make in
            make.trailing.equalTo(nameLabel.snp.leading).offset(-10)
            make.centerY.equalTo(nameLabel)
            
        }
        emailText.snp.makeConstraints { make in
            make.trailing.equalTo(emailLabel.snp.leading).offset(-10)
            make.centerY.equalTo(emailLabel)
            
        }
        phoneText.snp.makeConstraints { make in
            make.trailing.equalTo(phoneLabel.snp.leading).offset(-10)
            make.centerY.equalTo(phoneLabel)
        }
        ibanText.snp.makeConstraints { make in
            make.trailing.equalTo(ibanLabel.snp.leading).offset(-10)
            make.centerY.equalTo(ibanLabel)
            
        }
        salaryText.snp.makeConstraints { make in
            make.trailing.equalTo(salaryLabel.snp.leading).offset(-10)
            make.centerY.equalTo(salaryLabel)
        }
    }
    
    
}
